/*
 * Timer.h
 *
 *  Created on: Sep 22, 2023
 *      Author: michael.grathwohl
 */

#ifndef TIMER_H_
#define TIMER_H_

#include <cstdint>
#include <stdint.h>
#include "stm32f0xx_hal.h"
#include "CANHardwareInterface.h"
// Global hardware abstraction instance


class Timer
{
public:
	Timer(CANHardwareInterface& hw) : hardware(hw) {}
	//Timer() = default;
	virtual ~Timer() = default;

	void startTime(const uint32_t ms)
	{
		_waitTime_ms = ms;
		_startTime = hardware.GetTick();// Use abstraction layer
	};

	void stopTime() { _waitTime_ms = 0; }
	void resetTime() { _startTime = hardware.GetTick(); }// Use abstraction layer

	bool isTimeExpired()
	{
		bool retval = false;
		uint32_t diffTime = getCurrentDiffTime();

		if((_waitTime_ms > 0) && (diffTime > _waitTime_ms))
		{
			stopTime();
			retval = true;
			_diffTime_ms = diffTime;
		}
		return retval;
	};

	uint32_t getCurrentDiffTime() { return (hardware.GetTick() - _startTime); }// Use abstraction layer
	const uint32_t & getExpiredDiffTime() const { return _diffTime_ms; }

private:
	CANHardwareInterface& hardware; // Reference to abstraction

	uint32_t _startTime = 0;
	uint32_t _waitTime_ms = 0;
	uint32_t _diffTime_ms = 0;
};

#endif /* TIMER_H_ */
