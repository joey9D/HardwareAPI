var searchData=
[
  ['5_202015_2010_2020_0',['v0.5 - 2015-10-20',['../md_doc_2CHANGELOG.html#autotoc_md33',1,'']]]
];
