var searchData=
[
  ['base_0',['Data storage base',['../group__CO__storage.html',1,'']]],
  ['basic_20definitions_1',['Basic definitions',['../group__CO__dataTypes.html',1,'']]],
  ['buffer_2',['buffer',['../group__CO__STACK__CONFIG__FIFO.html',1,'FIFO buffer'],['../group__CO__CANopen__301__fifo.html',1,'FIFO circular buffer']]]
];
