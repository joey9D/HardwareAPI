var searchData=
[
  ['log_0',['Change Log',['../md_doc_2CHANGELOG.html',1,'']]]
];
