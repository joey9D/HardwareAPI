var searchData=
[
  ['bool_5ft_0',['bool_t',['../group__CO__dataTypes.html#ga490ee355f57f2815cb1aa4626cf525f7',1,'CO_driver.h']]]
];
