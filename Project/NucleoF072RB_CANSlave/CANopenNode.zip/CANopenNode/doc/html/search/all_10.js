var searchData=
[
  ['k20_20nxp_20arm_0',['Kinetis K20 (NXP Arm)',['../md_doc_2deviceSupport.html#autotoc_md44',1,'']]],
  ['kinetis_20k20_20nxp_20arm_1',['Kinetis K20 (NXP Arm)',['../md_doc_2deviceSupport.html#autotoc_md44',1,'']]]
];
