var searchData=
[
  ['od_5fattr_5ft_0',['OD_attr_t',['../group__CO__ODinterface.html#gac648abaac5839a871b39ee4c064c12ac',1,'CO_ODinterface.h']]],
  ['od_5fsize_5ft_1',['OD_size_t',['../group__CO__ODinterface.html#gaadf3e12bc9179030777eb4041fbf13ae',1,'CO_ODinterface.h']]]
];
