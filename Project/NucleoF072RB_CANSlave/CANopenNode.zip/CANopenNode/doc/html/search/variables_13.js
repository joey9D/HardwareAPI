var searchData=
[
  ['write_0',['write',['../structOD__IO__t.html#abc8a5fd5d118265a55f1ae003667abad',1,'OD_IO_t::write'],['../structOD__extension__t.html#adede22cfe8305c23356f3df04bdb98a8',1,'OD_extension_t::write']]],
  ['writeptr_1',['writeptr',['../structCO__fifo__t.html#a540fbc52344d1205de11625cd81f351d',1,'CO_fifo_t::writePtr'],['../structCO__trace__t.html#ae3a556a180e38e7247b39b84de609b5d',1,'CO_trace_t::writePtr']]]
];
