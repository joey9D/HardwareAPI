var searchData=
[
  ['16_20calculation_0',['CRC 16 calculation',['../group__CO__STACK__CONFIG__CRC16.html',1,'']]],
  ['16_20ccitt_1',['CRC 16 CCITT',['../group__CO__crc16__ccitt.html',1,'']]]
];
