var searchData=
[
  ['1_202004_2006_2029_0',['v0.1 - 2004-06-29',['../md_doc_2CHANGELOG.html#autotoc_md35',1,'']]],
  ['1_202019_2010_2008_1',['v1.1 - 2019-10-08',['../md_doc_2CHANGELOG.html#autotoc_md31',1,'']]],
  ['10_2008_2',['10 08',['../md_doc_2CHANGELOG.html#autotoc_md31',1,'v1.1 - 2019-10-08'],['../md_doc_2CHANGELOG.html#autotoc_md28',1,'v1.2 - 2019-10-08']]],
  ['10_2020_3',['v0.5 - 2015-10-20',['../md_doc_2CHANGELOG.html#autotoc_md33',1,'']]],
  ['16_20calculation_4',['CRC 16 calculation',['../group__CO__STACK__CONFIG__CRC16.html',1,'']]],
  ['16_20ccitt_5',['CRC 16 CCITT',['../group__CO__crc16__ccitt.html',1,'']]]
];
