var searchData=
[
  ['float32_5ft_0',['float32_t',['../group__CO__dataTypes.html#ga4611b605e45ab401f02cab15c5e38715',1,'CO_driver.h']]],
  ['float64_5ft_1',['float64_t',['../group__CO__dataTypes.html#gac55f3ae81b5bc9053760baacf57e47f4',1,'CO_driver.h']]]
];
