var searchData=
[
  ['xdd_20xpd_20file_20example_0',['XDD, XPD file example',['../md_doc_2objectDictionary.html#autotoc_md54',1,'']]],
  ['xml_20device_20description_1',['XML Device Description',['../md_doc_2objectDictionary.html#xml-device-description',1,'']]],
  ['xpd_20file_20example_2',['XDD, XPD file example',['../md_doc_2objectDictionary.html#autotoc_md54',1,'']]]
];
