var searchData=
[
  ['2_202019_2010_2008_0',['v1.2 - 2019-10-08',['../md_doc_2CHANGELOG.html#autotoc_md28',1,'']]],
  ['20_1',['v0.5 - 2015-10-20',['../md_doc_2CHANGELOG.html#autotoc_md33',1,'']]],
  ['2004_2006_2029_2',['v0.1 - 2004-06-29',['../md_doc_2CHANGELOG.html#autotoc_md35',1,'']]],
  ['2012_2002_2026_3',['v0.4 - 2012-02-26',['../md_doc_2CHANGELOG.html#autotoc_md34',1,'']]],
  ['2015_2010_2020_4',['v0.5 - 2015-10-20',['../md_doc_2CHANGELOG.html#autotoc_md33',1,'']]],
  ['2017_2008_2001_5',['v1.0 - 2017-08-01',['../md_doc_2CHANGELOG.html#autotoc_md32',1,'']]],
  ['2019_2010_2008_6',['2019 10 08',['../md_doc_2CHANGELOG.html#autotoc_md31',1,'v1.1 - 2019-10-08'],['../md_doc_2CHANGELOG.html#autotoc_md28',1,'v1.2 - 2019-10-08']]],
  ['2020_2002_2025_7',['v2.0 - 2020-02-25',['../md_doc_2CHANGELOG.html#autotoc_md18',1,'']]],
  ['2020_2004_2027_8',['v1.3 - 2020-04-27',['../md_doc_2CHANGELOG.html#autotoc_md24',1,'']]],
  ['25_9',['v2.0 - 2020-02-25',['../md_doc_2CHANGELOG.html#autotoc_md18',1,'']]],
  ['26_10',['v0.4 - 2012-02-26',['../md_doc_2CHANGELOG.html#autotoc_md34',1,'']]],
  ['27_11',['v1.3 - 2020-04-27',['../md_doc_2CHANGELOG.html#autotoc_md24',1,'']]],
  ['29_12',['v0.1 - 2004-06-29',['../md_doc_2CHANGELOG.html#autotoc_md35',1,'']]]
];
