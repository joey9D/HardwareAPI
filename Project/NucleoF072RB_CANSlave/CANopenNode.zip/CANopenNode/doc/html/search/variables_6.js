var searchData=
[
  ['gfc_0',['GFC',['../structCO__t.html#a9c6e7b29436b05c8b659502c6fae2a6a',1,'CO_t']]],
  ['gtwa_1',['gtwa',['../structCO__t.html#afa0e937046492a26af9bb5e03c3aab94',1,'CO_t']]]
];
