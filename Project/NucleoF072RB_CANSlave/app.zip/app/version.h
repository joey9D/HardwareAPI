/*
 * version.h
 *
 *  Created on: Dec 7, 2023
 *      Author: michael.grathwohl
 */

#ifndef VERSION_H_
#define VERSION_H_

#define APP_MAJOR		0
#define APP_MINOR		0
#define APP_REVISION	0

#endif /* VERSION_H_ */
