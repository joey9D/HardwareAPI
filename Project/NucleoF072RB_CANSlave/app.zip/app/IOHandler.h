/*
 * IOHandler.h
 *
 *  Created on: Dec 18, 2023
 *      Author: michael.grathwohl
 */

#ifndef IOHANDLER_H_
#define IOHANDLER_H_

#include <stdint.h>
#include <assert.h>
#include "../basic/Timer.h"
#include "main.h"
#include "CANHardwareInterface.h"

//#include "Hardware_Abstraction/STM32/STM32CANHardware.h"
// Global instance of hardware abstraction

//extern STM32CANHardware hardware;

class GPIOBasic
{
public:

	GPIOBasic(uint16_t Pin, GPIO_TypeDef* Port, bool inverted = false)
	{
		assert(Port != NULL);

		_Pin = Pin;
		_Port = Port;
		_invertedPin = inverted;
	};

	virtual ~GPIOBasic()
	{};

	uint16_t getPin()
	{
		return _Pin;
	};

	GPIO_TypeDef* getPort()
	{
		return _Port;
	};

	bool isPinInverted()
	{
		return _invertedPin;
	};

private:

	uint16_t _Pin = 0;
	GPIO_TypeDef* _Port = nullptr;
	bool _invertedPin = false;
};

class GPIOInput : public GPIOBasic
{
public:

	GPIOInput(uint16_t Pin, GPIO_TypeDef* Port, bool inverted,CANHardwareInterface& hw, uint32_t debounceTime = 0) : GPIOBasic(Pin, Port, inverted) , hardware(hw),_debounceTimer(hw)
	{
		_debounceTime = debounceTime;
	};

	bool isPinOn()
	{
		bool retval = false;

		//if(HAL_GPIO_ReadPin(getPort(), getPin()) == GPIO_PIN_SET)
	    // Use the abstraction layer to read the pin state
		if (hardware.GPIO_Read(getPin()))
		{
			retval = true;
		}
		if(isPinInverted())
		{
			retval = !retval;
		}
		return retval;
	};

	bool isDebouncePinOn()
	{
		bool retval = false;

		if(_debounceTime != 0)
		{
			switch(_debounceState)
			{
			case 0://pin off idle
				if(isPinOn())
				{
					_debounceTimer.startTime(_debounceTime);
					_debounceState = 1;//pin off debounce
				}
				break;
			case 1://pin off debounce
				if(isPinOn())
				{
					if(_debounceTimer.isTimeExpired())
					{
						_debounceState = 2;
					}
				}
				else
				{
					_debounceTimer.stopTime();
					_debounceState = 0;//pin off idle
				}
				break;
			case 2://pin on idle
				retval = true;
				if(!isPinOn())
				{
					_debounceTimer.startTime(_debounceTime);
					_debounceState = 3;//pin on debounce
				}
				break;
			case 3://pin on debounce
				retval = true;
				if(!isPinOn())
				{
					if(_debounceTimer.isTimeExpired())
					{
						_debounceState = 0;//pin off idle
					}
				}
				else
				{
					_debounceTimer.stopTime();
					_debounceState = 2;//pin on idle
				}
				break;
			default:
				_debounceState = 0;
				break;
			}
		}
		else
		{
			retval = isPinOn();
		}

		return retval;
	};

private:
	CANHardwareInterface& hardware;

	uint32_t _debounceTime = 0;
	Timer _debounceTimer;
	uint8_t _debounceState = 0;
};

class GPIOOutput : public GPIOBasic
{
public:

	GPIOOutput(uint16_t Pin, GPIO_TypeDef* Port, bool inverted , CANHardwareInterface& hw) : GPIOBasic(Pin, Port, inverted), hardware(hw)
	{
		setOutput(false);
	};

	void setOutput(bool onState)
	{
		if(_oldState != onState)
		{
//			GPIO_PinState PinState;
			_oldState = onState;
			// Applying Inversion Logic
			bool outputValue =onState;
			if(isPinInverted())
			{
	            outputValue = !outputValue;
			}

			hardware.GPIO_Write(getPin(), outputValue);
		}
	};

	void toggle()
	{
		setOutput(!_oldState);
	};

	bool isPinOn()
	{
		return _oldState;
	};

private:
	CANHardwareInterface& hardware;
	bool _oldState = true;
};

#endif /* IOHANDLER_H_ */
